

# Constants for process states
READY = 1       
BLOCKED = 0

#Constants for resource states
FREE = 1
ALLOCATED = 0
