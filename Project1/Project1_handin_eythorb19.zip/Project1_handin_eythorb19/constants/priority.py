#   Priorities for the processes
LOW = 0
MED = 1
HIGH = 2